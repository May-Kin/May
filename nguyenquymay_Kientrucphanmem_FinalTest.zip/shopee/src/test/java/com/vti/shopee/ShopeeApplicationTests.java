package com.vti.shopee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
