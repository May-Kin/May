package com.vti.shopee.controller;

import com.vti.shopee.model.Product;
import com.vti.shopee.model.ResponseObject;
import com.vti.shopee.repository.ProductRepository;
import com.vti.shopee.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping(path = "/api/v1/Products")
public class ProductController {

    @Autowired
    private ProductService productService;
    @Autowired
    private ProductRepository productRepository;

    @GetMapping("")
    ResponseEntity<ResponseObject> getProduct() {
        List<Product> productsList = productRepository.findAll();
        return ResponseEntity.status(HttpStatus.OK).
                body(new ResponseObject("ok", "Insert product successfully", productsList));

    }

    @GetMapping("/{id}")
    ResponseEntity<ResponseObject> getproductInfo(@PathVariable Long id) {
        Optional<Product> foundProduct = productRepository.findById(id);
        if (foundProduct.isPresent()) {
            return ResponseEntity.status(HttpStatus.OK).
                    body(new ResponseObject("ok", "success", foundProduct.get()));

        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).
                body(new ResponseObject("ok", "Product not found", ""));
    }

    @GetMapping("/name")
    ResponseEntity<ResponseObject> searchProductByName(@RequestParam String name) {
        List<Product> productList = productService.searchStudentByName(name);
        if (productList.size() == 0) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).
                    body(new ResponseObject("ok", "Product Name not found", ""));
        }
        return ResponseEntity.status(HttpStatus.OK).
                body(new ResponseObject("ok", "success", productList));

    }

    @DeleteMapping("/{id}")
    ResponseEntity<ResponseObject> deleteProduct(@PathVariable Long id) {
        Optional<Product> foundProduct = productRepository.findById(id);
        if (foundProduct.isPresent()) {
            productRepository.deleteById(id);
            return ResponseEntity.status(HttpStatus.OK).
                    body(new ResponseObject("ok", "success", foundProduct.get()));
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).
                body(new ResponseObject("ok", "product not found", ""));
    }

    @PostMapping("/insert")
    ResponseEntity<ResponseObject> insertProduct(@RequestBody Product newProduct) {

        Optional<Product> foundProduct = productRepository.findById(newProduct.getId());

        if (foundProduct.isPresent()) {

            return ResponseEntity.status(HttpStatus.NOT_IMPLEMENTED).body(
                    new ResponseObject("ok", "Product Id aldready taken", "")
            );
        }
        return getProduct();
    }

    @PutMapping("/{id}")
    ResponseEntity<ResponseObject> updateProduct(@RequestBody Product newProduct, @PathVariable Long id) {

        Optional<Product> foundProduct = productRepository.findById(id);
        if (foundProduct.isPresent()) {
            Product product = new Product();
            product.setId(id);
            product.setName(newProduct.getName());
            product.setUrl(product.getUrl());
            product.setCreateDate(new Date());
            return ResponseEntity.status(HttpStatus.OK).
                    body(new ResponseObject("ok", "Insert product successfully",
                            productRepository.save(product)));

        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).
                body(new ResponseObject("ok", "product not found", ""));


    }
}



