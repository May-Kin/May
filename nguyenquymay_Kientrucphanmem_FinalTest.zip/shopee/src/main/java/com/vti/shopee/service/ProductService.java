package com.vti.shopee.service;

import com.vti.shopee.model.Product;
import com.vti.shopee.model.ResponseObject;
import com.vti.shopee.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
@Configurable
public class ProductService {
    @Autowired
    private ProductRepository productRepository;

    public List<Product>  searchStudentByName(String keyword)
    {
        List<Product> returnList = new ArrayList<>();

        for(Product product: productRepository.findAll())
        {
            if(product.getName().toLowerCase().trim().replace(" ","")
                    .contains(keyword.toLowerCase().trim().replace(" ","")))
            {
                returnList.add(product);
            }

        }
        return returnList;
    }




    }




